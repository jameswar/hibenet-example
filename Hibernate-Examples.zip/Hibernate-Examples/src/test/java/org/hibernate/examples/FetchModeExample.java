package org.hibernate.examples;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class FetchModeExample {

	private static SessionFactory sessionFactory;

	private static Customer cusomter;

	@BeforeAll
	public static void setUp() {
		StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();

        Map<String, String> settings = new HashMap<>();
        settings.put(Environment.DRIVER, "org.h2.Driver");
        settings.put(Environment.URL, "jdbc:h2:mem:test");
        settings.put(Environment.USER, "sa");
        settings.put(Environment.PASS, "");
        settings.put(Environment.DIALECT, "org.hibernate.dialect.H2Dialect");
        settings.put(Environment.HBM2DDL_AUTO, "create-drop");
        settings.put(Environment.SHOW_SQL, "true");
        settings.put(Environment.GENERATE_STATISTICS, "true");
        registryBuilder.applySettings(settings);

        // Create registry
        StandardServiceRegistry  registry = registryBuilder.build();

        // Create MetadataSources
        MetadataSources sources = new MetadataSources(registry);
        sources.addAnnotatedClass(Customer.class);
        sources.addAnnotatedClass(Orders.class);
        // Create Metadata
        Metadata metadata = sources.getMetadataBuilder().build();

        // Create SessionFactory
        sessionFactory = metadata.getSessionFactoryBuilder().build();
		cusomter = new Customer();
		Customer c2 = new Customer();
		Orders o1 = new Orders();
		o1.setCustomer(cusomter);
		Orders o2 = new Orders();
		o2.setCustomer(cusomter);
		Set<Orders> cOrders = new HashSet<Orders>();
		cOrders.add(o1);
		cOrders.add(o2);
		cusomter.setOrders(cOrders);
		Orders o3 = new Orders();
		o3.setCustomer(c2);
		Orders o4 = new Orders();
		o4.setCustomer(c2);
		Set<Orders> cOrders2 = new HashSet<Orders>();
		cOrders2.add(o3);
		cOrders2.add(o4);
		c2.setOrders(cOrders2);
		Session session = sessionFactory.openSession();
		session.save(o1);
		session.save(o2);
		session.save(cusomter);
		session.save(o3);
		session.save(o4);
		session.save(c2);
		session.beginTransaction().commit();
		session.close();
	}

	@Test
	public void testFetchModes() {
		Session session = sessionFactory.openSession();		
		List<Customer> cusomter1 = session.createCriteria(Customer.class).list();
		for (Customer cus : cusomter1) {
			assertTrue(cus.getOrders().stream().allMatch(order -> order.getCustomer().getId()>0));
		}

		session.close();
	}

	@AfterAll
	public static void tearDown() {
		Optional.ofNullable(sessionFactory).ifPresent(e -> e.close());
	}
}
